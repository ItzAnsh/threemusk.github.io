new TypeIt("#simpleUsage", {
	strings: "Explore me :)",
	speed: 100,
	waitUntilVisible: true,
}).go();
